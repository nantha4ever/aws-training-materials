angular.module('app', [])
  .controller('MainCtrl', function($scope, $http){
    var self = $scope;
    var apiUrl = 'https://nuu2t23hog.execute-api.us-east-1.amazonaws.com/ep33-prod';

    self.contacts = [];
    self.contact = {};
    self.error = '';

    self.getContacts = function(){

      console.log("Before GET");

      $http.get(apiUrl).then(function(res){
        self.contacts = res.data;
        console.log("Return : "+self.contacts.length);
        console.log("Object type : "+ typeof (self.contacts));

      }, function(err){
        consol.log("Error");
        self.error = err.data.status;
      });
    }

    self.create = function(){
      console.log("Before POST");

      $http.post(apiUrl, self.contact).then(function(res){
        self.getContacts();
        self.contact = '';
        self.error = '';
      }, function(err){
        self.error = err.data.status;
      });
    }

    self.getContacts();
  });