import json
import os
import boto3

from boto3.dynamodb.conditions import Key, Attr



dynamodb = boto3.resource('dynamodb')


def list(event, context):
    table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

    # fetch all entries from the database
    result = table.scan()
    
    return result['Items']
    
    