package com.javasampleapproach.angularjpamysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaMySqlAngularJsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaMySqlAngularJsApplication.class, args);
	}
}
