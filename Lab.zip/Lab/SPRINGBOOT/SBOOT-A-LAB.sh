 
 aws --version

 mvn --version

 aws configure

 sudo apt-get install unzip

  aws s3 cp s3://epsh-lab/lab/Day02/SpringJPAMySQLAngularJS.zip .

 unzip SpringJPAMySQLAngularJS.zip 

 cd SpringJPAMySQLAngularJS/

 cd src/main/resources/
 
 vim application.properties

      change mysql IP address


 cd ~/SpringJPAMySQLAngularJS/

 mvn package
 
 sudo apt-get install tomcat8
 
 cd /var/lib/tomcat8
 
 cd webapps

 cd ROOT
 
 sudo rm -r *

 sudo mv ~/SpringJPAMySQLAngularJS/target/spring-jpa-mysql-angularjs-0.0.1-SNAPSHOT.war ../ROOT.war
 